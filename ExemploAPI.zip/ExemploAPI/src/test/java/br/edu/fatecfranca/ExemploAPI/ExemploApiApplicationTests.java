package br.edu.fatecfranca.ExemploAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
